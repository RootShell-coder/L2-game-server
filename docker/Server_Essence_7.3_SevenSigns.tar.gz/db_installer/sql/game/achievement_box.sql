DROP TABLE IF EXISTS `achievement_box`;
CREATE TABLE IF NOT EXISTS `achievement_box` (
`charId` INT,
`box_owned` INT NOT NULL DEFAULT 1,
`monster_point` INT NOT NULL DEFAULT 0,
`pvp_point` INT NOT NULL DEFAULT 0,
`pending_box` INT NOT NULL DEFAULT 0,
`open_time` BIGINT UNSIGNED NOT NULL DEFAULT 0,
`box_state_slot_1` INT NOT NULL DEFAULT 1,
`boxtype_slot_1` INT NOT NULL DEFAULT 0,
`box_state_slot_2` INT NOT NULL DEFAULT 0,
`boxtype_slot_2` INT NOT NULL DEFAULT 0,
`box_state_slot_3` INT NOT NULL DEFAULT 0,
`boxtype_slot_3` INT NOT NULL DEFAULT 0,
`box_state_slot_4` INT NOT NULL DEFAULT 0,
`boxtype_slot_4` INT NOT NULL DEFAULT 0,
PRIMARY KEY (`charId`)
) DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;