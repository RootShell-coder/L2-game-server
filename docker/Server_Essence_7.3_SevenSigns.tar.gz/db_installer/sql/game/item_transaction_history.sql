DROP TABLE IF EXISTS `item_transaction_history`;
CREATE TABLE IF NOT EXISTS `item_transaction_history` (
   `created_time` BIGINT UNSIGNED NOT NULL,
   `item_id` INT NOT NULL,
   `transaction_type` INT NOT NULL,
   `enchant_level` INT NOT NULL,
   `price` BIGINT UNSIGNED NOT NULL,
   `count` BIGINT UNSIGNED NOT NULL,
   PRIMARY KEY (`created_time`)
) DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;